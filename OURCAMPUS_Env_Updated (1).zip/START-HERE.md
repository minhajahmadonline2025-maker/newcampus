# Put OURCAMPUS online (GitHub + Vercel + Supabase)

## 1. GitHub: upload the files, not the zip
GitHub does **not** unzip files. If you upload `ourcampus-github.zip` itself, Vercel shows **404**.

1. On your computer: right-click the zip → **Extract All** → open the extracted folder.
   You should see `api`, `docs`, `public`, `server`, `src`, `supabase`, `tests`, `index.html`, `package.json`, `vercel.json` …
2. In your GitHub repository, **delete** the old zip file (open it → ⋯ → Delete file → Commit).
3. Click **Add file → Upload files**.
4. Inside the extracted folder press **Ctrl + A** (select everything) and drag it onto the GitHub page. Then click **Commit changes**.
5. Check the repository's main page: `package.json` and `vercel.json` must be at the **top level**, not inside another folder.

## 2. Supabase: create the database (once)
1. Supabase → your project → **SQL Editor → New query**.
2. Paste everything from `supabase/migrations/20261117000000_init.sql` → **Run**.
3. **Authentication → Sign In / Providers** → turn off "Allow new users to sign up".
4. **Project Settings → API**: copy the **Project URL**, the **anon** key and the **service_role** key.

## 3. Vercel: settings
Vercel → your project → **Settings → Environment Variables**. Add all four:

| Name | Value |
|---|---|
| `VITE_SUPABASE_URL` | Project URL |
| `VITE_SUPABASE_ANON_KEY` | anon key |
| `SUPABASE_URL` | Project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | service_role key (secret) |

Then **Deployments → ⋯ → Redeploy**.
(If Vercel asks: Framework = **Vite**, Root Directory = **./**, Build = `npm run build`, Output = `dist`.)

## 4. Create the sign-in accounts (once)
On your computer, in this folder (needs Node.js 20+):
```
npm install
copy .env.example .env      (then fill in the same 4 values in .env)
npm run accounts:create -- private/accounts.csv
```
`private/accounts.csv` is in the earlier project folder (`Downloads\campus\ourcampus\private`). Copy that `private` folder here first, and **never upload it to GitHub**.

## 5. Open your site
Open `https://<your-project>.vercel.app` and sign in as **ADMIN** first.
Check the API works: `https://<your-project>.vercel.app/api/health` should show `{"ok":true,"configured":true,…}`.
